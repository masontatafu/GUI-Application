using Assign_2;
using Microsoft.VisualBasic.ApplicationServices;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.Devices;
using Microsoft.VisualBasic.Logging;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.Metrics;
using System.Diagnostics;
using System;
using System.Net;
using System.Net.Http.Headers;
using System.Net.NetworkInformation;
using System.Runtime.Intrinsics.X86;
using System.Text.Json;
using static System.Runtime.InteropServices.JavaScript.JSType;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;
using System.Text.Json.Serialization;

namespace Assign_2
{
    public partial class Form1 : Form
    {
        //initializing ImageId as a string
        private string image_id = ""; //storing the image ID for viewing artwork images
        private string selectedArtworkId = ""; // storing the ID of the currently selected artwork 
        private List<Artwork>? artworksList = new List<Artwork>(); // holds list of artworks fetched from API

        public Form1()
        {
            InitializeComponent();
            //insuring that listview columns are set up properly
            listViewBox.View = View.Details;
            listViewBox.FullRowSelect = true;
            listViewBox.HideSelection = false;
            listViewBox.Columns.Add("Title", 150);
            listViewBox.Columns.Add("Artist", 120);
            listViewBox.Columns.Add("Date", 100);
            LoadArtworks(); //method to get atwork from API
        }
        private async void LoadArtworks()
        {
            // API endpoint to get the artwork data
            string uri = "https://api.artic.edu/api/v1/artworks?fields=id,title,artist_title,image_id,date_display,thumbnail,medium_display&page=1&limit=30";
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    //added user-agent header because it wasn't allowing access to the API - it prevents api rejection
                    client.DefaultRequestHeaders.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3");

                    HttpResponseMessage response = await client.GetAsync(uri); // sends GET request to the API endpoint
                    response.EnsureSuccessStatusCode(); //ensure response is successful, throws error if request failed


                    string json = await response.Content.ReadAsStringAsync(); //reads JSON response as a string


                    var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true }; //options to configure JSON deserialization


                    var data = JsonSerializer.Deserialize<ArtworkResponse>(json, options); // Deserializes the JSON response into an ArtworkResponse object

                    //checks if the API returned a valid artwork list
                    if (data?.Data != null)
                    {
                        artworksList = data.Data; //Store the retrieved artworks in a list
                        Console.WriteLine($"successfully loaded {artworksList.Count} artworks."); //debugging
                        PopulateListView(); // calls the populatelistview method to display the artowrks in Listview
                    }
                    else
                    {
                        Console.WriteLine("No artowkrs recieved from api"); //debugging
                    }
                }
            }
            //error message if something goes wrong
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading artwork data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void PopulateListView()
        {
            listViewBox.Items.Clear();  // Clear the list view before populating

            //checks if there are any artworks in the list
            if (artworksList == null || artworksList.Count == 0)
            {
                MessageBox.Show("No artwork data avaialable", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            //loops through each artwork in the retrieved list
            foreach (var artwork in artworksList) // Loop through artworks in artworksList
            {
                Console.WriteLine($"Artwork: {artwork.Title}, Image ID: {artwork.ImageId}"); // Debugging

                // Create a new ListViewItem for each artwork
                ListViewItem item = new ListViewItem(artwork.Title ?? "Untitled");
                item.SubItems.Add(artwork.ArtistTitle ?? "Unknown Artist");
                item.SubItems.Add(artwork.DateDisplay ?? "Unknown Date");

                Console.WriteLine($"Selected Artwork image_id: {artwork.ImageId}");
                // Ensure ImageId is not null before assigning it to Tag

                //stores the 'id' in the Tag (needed for fetching details)
                if (artwork.Id > 0)
                {
                    item.Tag = artwork.Id.ToString();  // 
                    Console.WriteLine($"Setting Tag: {artwork.Id}"); //debugging
                }
                else
                {
                    item.Tag = "NO_IMAGE_ID"; //assigning a placeholder value 
                    Console.WriteLine($"Warning: Image ID is null for {artwork.Title}");
                }

                // Add the ListViewItem to the listViewBox
                listViewBox.Items.Add(item);
            }
            Console.WriteLine($"Listview now has {listViewBox.Items.Count} items"); //debugging
        }



        private void listViewBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            Debug.WriteLine("SelectedIndexChanged event triggered.");

            // if no item is selected, reset stored values
            if (listViewBox.SelectedItems.Count == 0)
            {
                Debug.WriteLine("No artwork selected.");
                selectedArtworkId = "";
                image_id = "";
                return;
            }

            var selectedItem = listViewBox.SelectedItems[0];
            var selectedTag = selectedItem.Tag?.ToString();

            Debug.WriteLine($"Selected Item: {selectedItem.Text} | Tag (ID): {selectedTag}");

            if (!string.IsNullOrEmpty(selectedTag) && selectedTag != "NO_ID")
            {
                selectedArtworkId = selectedTag; // stores the 'id' for fetching details
                Console.WriteLine($"Successfully set selectedArtworkId: {selectedArtworkId}");

                // Find the corresponding artwork to get `image_id`
                Artwork selectedArtwork = artworksList.FirstOrDefault(a => a.Id.ToString() == selectedArtworkId);
                if (selectedArtwork != null && !string.IsNullOrEmpty(selectedArtwork.ImageId))
                {
                    image_id = selectedArtwork.ImageId;
                    Console.WriteLine($"Successfully set image_id: {image_id}");
                }
                else
                {
                    image_id = "";
                    Console.WriteLine("Warning: No image available for this artwork.");
                }
            }
            else
            {
                selectedArtworkId = "";
                image_id = "";
                Console.WriteLine("Selected item does not have a valid ID.");
            }
        }

        /*private void viewBttn_Click(object sender, EventArgs e)    
        {
            if (string.IsNullOrEmpty(image_id) || image_id == "NO_IMAGE_ID")
            {
                MessageBox.Show("Selected item does not have a valid image.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Console.WriteLine($"Viewing artwork with image_id: {image_id}");

            string imageUrl = $"https://www.artic.edu/iiif/2/{image_id}/full/843,/0/default.jpg";
            Process.Start(new ProcessStartInfo
            {
                FileName = imageUrl,
                UseShellExecute = true
            });
        }
        */

        private async void viewBttn_Click(object sender, EventArgs e)
        {
            // Check if `image_id` exists and is valid
            if (string.IsNullOrEmpty(image_id) || image_id == "NO_IMAGE_ID")
            {
                MessageBox.Show("Selected item does not have a valid image.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Console.WriteLine($"Attempting to load image with image_id: {image_id}");

            // Construct the correct API URL for the image
            string imageUrl = $"https://www.artic.edu/iiif/2/{image_id}/full/843,/0/default.jpg";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)");

                    // Await the HTTP response asynchronously
                    HttpResponseMessage response = await client.GetAsync(imageUrl);

                    // Ensure the request was successful
                    if (!response.IsSuccessStatusCode)
                    {
                        Console.WriteLine($"API Error: {response.StatusCode}");
                        MessageBox.Show($"Error: Could not load image (Status: {response.StatusCode})", "Image Load Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    // Await the image download as a byte array
                    byte[] imageData = await response.Content.ReadAsByteArrayAsync();

                    // Use a MemoryStream to convert the byte array into an image
                    using (var ms = new System.IO.MemoryStream(imageData))
                    {
                        pictureBoxArtwork.Image = System.Drawing.Image.FromStream(ms); // Display image in PictureBox
                    }

                    Console.WriteLine("Image loaded successfully.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error loading image: {ex.Message}");
                MessageBox.Show($"Error loading image: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //made async to be able to use await
        private async void detailsBttn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(selectedArtworkId))
            {
                MessageBox.Show("Please select an artwork first.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Console.WriteLine($"Fetching details for Artwork ID: {selectedArtworkId}");

            string detailsUri = $"https://api.artic.edu/api/v1/artworks/{selectedArtworkId}?fields=id,title,artist_title,date_display,thumbnail,medium_display";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)");

                    HttpResponseMessage response = await client.GetAsync(detailsUri);

                    if (!response.IsSuccessStatusCode)
                    {
                        Console.WriteLine($"API Error: {response.StatusCode}");
                        MessageBox.Show($"Error fetching artwork details: {response.StatusCode}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    string json = await response.Content.ReadAsStringAsync();
                    Console.WriteLine($"API Response: {json}"); // Debugging output

                    var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
                    var data = JsonSerializer.Deserialize<SingleArtworkResponse>(json, options);

                    if (data?.Data != null)
                    {
                        Artwork artwork = data.Data;

                        string details = $"Title: {artwork.Title ?? ""}\n" +
                                         $"Artist: {artwork.ArtistTitle ?? ""}\n" +
                                         $"Date: {artwork.DateDisplay ?? ""}\n" +
                                         $"Medium: {artwork.MediumDisplay ?? ""}";

                        MessageBox.Show(details, "Artwork Details", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("No details found for this artwork.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error fetching artwork details: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBoxArtwork_Click(object sender, EventArgs e)
        {

        }
    }
}

public class Artwork
{
    public int Id { get; set; }

    [JsonPropertyName("title")]
    public string? Title { get; set; }

    [JsonPropertyName("artist_title")]
    public string? ArtistTitle { get; set; }

    [JsonPropertyName("image_id")]
    public string? ImageId { get; set; }

    [JsonPropertyName("date_display")]
    public string? DateDisplay { get; set; }

    public Thumbnail? Thumbnail { get; set; }

    [JsonPropertyName("medium_display")]
    public string? MediumDisplay { get; set; }
}
//Thumbnail has it's own values within the data
//? to cover if the fields are null in the API
public class Thumbnail
{
    public string? Lqip { get; set; }
    public int? Width { get; set; }
    public int? Height { get; set; }
    public string? AltText { get; set; }
}
public class ArtworkResponse
{
    //// The 'Data' property contains a list of 'Artwork' objects. 
    //? means it can be null if no data in the API
    public List<Artwork>? Data { get; set; }
}
public class SingleArtworkResponse
{
    public Artwork? Data { get; set; }
}



















