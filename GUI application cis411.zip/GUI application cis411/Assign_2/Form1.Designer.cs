﻿namespace Assign_2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            ListViewItem listViewItem2 = new ListViewItem("");
            detailsBttn = new Button();
            viewBttn = new Button();
            listViewBox = new ListView();
            imageListView = new ImageList(components);
            pictureBoxArtwork = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBoxArtwork).BeginInit();
            SuspendLayout();
            // 
            // detailsBttn
            // 
            detailsBttn.Location = new Point(65, 239);
            detailsBttn.Margin = new Padding(3, 2, 3, 2);
            detailsBttn.Name = "detailsBttn";
            detailsBttn.Size = new Size(82, 22);
            detailsBttn.TabIndex = 0;
            detailsBttn.Text = "Details";
            detailsBttn.UseVisualStyleBackColor = true;
            detailsBttn.Click += detailsBttn_Click;
            // 
            // viewBttn
            // 
            viewBttn.Location = new Point(193, 240);
            viewBttn.Margin = new Padding(3, 2, 3, 2);
            viewBttn.Name = "viewBttn";
            viewBttn.Size = new Size(82, 22);
            viewBttn.TabIndex = 1;
            viewBttn.Text = "View";
            viewBttn.UseVisualStyleBackColor = true;
            viewBttn.Click += viewBttn_Click;
            // 
            // listViewBox
            // 
            listViewBox.FullRowSelect = true;
            listViewBox.Items.AddRange(new ListViewItem[] { listViewItem2 });
            listViewBox.LargeImageList = imageListView;
            listViewBox.Location = new Point(32, 25);
            listViewBox.Margin = new Padding(3, 2, 3, 2);
            listViewBox.MultiSelect = false;
            listViewBox.Name = "listViewBox";
            listViewBox.Size = new Size(260, 194);
            listViewBox.SmallImageList = imageListView;
            listViewBox.TabIndex = 2;
            listViewBox.UseCompatibleStateImageBehavior = false;
            listViewBox.View = View.Details;
            listViewBox.SelectedIndexChanged += listViewBox_SelectedIndexChanged;
            // 
            // imageListView
            // 
            imageListView.ColorDepth = ColorDepth.Depth32Bit;
            imageListView.ImageSize = new Size(16, 16);
            imageListView.TransparentColor = Color.Transparent;
            // 
            // pictureBoxArtwork
            // 
            pictureBoxArtwork.Location = new Point(374, 25);
            pictureBoxArtwork.Name = "pictureBoxArtwork";
            pictureBoxArtwork.Size = new Size(259, 194);
            pictureBoxArtwork.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBoxArtwork.TabIndex = 3;
            pictureBoxArtwork.TabStop = false;
            pictureBoxArtwork.Click += pictureBoxArtwork_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(700, 338);
            Controls.Add(pictureBoxArtwork);
            Controls.Add(listViewBox);
            Controls.Add(viewBttn);
            Controls.Add(detailsBttn);
            Margin = new Padding(3, 2, 3, 2);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)pictureBoxArtwork).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button detailsBttn;
        private Button viewBttn;
        private ListView listViewBox;
        private ImageList imageListView;
        private PictureBox pictureBoxArtwork;
    }
}
